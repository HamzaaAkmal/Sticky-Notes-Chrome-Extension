document.addEventListener('DOMContentLoaded', () => {
  const notesContainer = document.getElementById('notes-container');
  const searchInput = document.getElementById('search-input');
  let allNotesData = {}; // To cache all notes from storage
  let collapsedDomainsState = []; // To cache the collapsed state

  // Theme colors configuration
  const THEME_COLORS = {
    yellow: { start: '#ffd165', end: '#ffb84d', bg: '#fff9e6', bgEnd: '#fff3d4', border: '#ffe9b3' },
    pink: { start: '#ff9b71', end: '#ff7f6e', bg: '#ffe9e6', bgEnd: '#ffd9d4', border: '#ffb3a8' },
    blue: { start: '#a0d1e8', end: '#7eb5d3', bg: '#e6f4f9', bgEnd: '#d4ebf4', border: '#b3dce9' },
    purple: { start: '#d3a0e8', end: '#b77ed3', bg: '#f4e6f9', bgEnd: '#ebd4f4', border: '#dcb3e9' },
    green: { start: '#a0e8b1', end: '#7ed396', bg: '#e6f9eb', bgEnd: '#d4f4dd', border: '#b3e9c4' },
    red: { start: '#e8a0a0', end: '#d37e7e', bg: '#f9e6e6', bgEnd: '#f4d4d4', border: '#e9b3b3' }
  };

  // Load saved theme or default to yellow
  function loadTheme() {
    chrome.storage.local.get(['dashboardTheme'], (result) => {
      const theme = result.dashboardTheme || 'yellow';
      applyTheme(theme);
    });
  }

  // Apply theme to popup
  function applyTheme(colorKey) {
    const colors = THEME_COLORS[colorKey];
    const root = document.documentElement;
    
    root.style.setProperty('--primary-start', colors.start);
    root.style.setProperty('--primary-end', colors.end);
    root.style.setProperty('--bg-color', colors.bg);
    root.style.setProperty('--border-color', colors.border);
    
    // Update sticky box header background
    const stickyBox = document.querySelector('.sticky-box');
    if (stickyBox) {
      stickyBox.style.background = `linear-gradient(135deg, ${colors.bg} 0%, ${colors.bgEnd} 100%)`;
    }
    
    // Update banner
    const banner = document.querySelector('.rate-banner');
    if (banner) {
      banner.style.background = `linear-gradient(135deg, ${colors.start} 0%, ${colors.end} 100%)`;
    }
    
    // Update banner CTA color
    const bannerCta = document.querySelector('.banner-cta');
    if (bannerCta) {
      bannerCta.style.color = colors.end;
    }
    
    // Update theme picker button border
    const themeBtn = document.getElementById('popup-theme-picker-btn');
    if (themeBtn) {
      themeBtn.style.borderColor = colors.border;
      themeBtn.querySelector('i').style.color = colors.start;
    }
    
    // Update search and dashboard button borders
    const searchContainer = document.querySelector('.search-container');
    const dashboardBtn = document.querySelector('.open-dashboard-btn');
    if (searchContainer) searchContainer.style.borderColor = colors.border;
    if (dashboardBtn) dashboardBtn.style.borderColor = colors.border;
    
    // Save theme preference
    chrome.storage.local.set({ dashboardTheme: colorKey });
    
    // Update active swatch
    document.querySelectorAll('.popup-color-swatch').forEach(swatch => {
      swatch.classList.toggle('active', swatch.dataset.color === colorKey);
    });
  }

  // Theme picker functionality
  function initThemePicker() {
    const themeBtn = document.getElementById('popup-theme-picker-btn');
    const themePalette = document.getElementById('popup-theme-palette');
    
    if (!themeBtn || !themePalette) return;
    
    themeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      themePalette.classList.toggle('show');
    });
    
    document.querySelectorAll('.popup-color-swatch').forEach(swatch => {
      swatch.addEventListener('click', (e) => {
        e.stopPropagation();
        const colorKey = swatch.dataset.color;
        applyTheme(colorKey);
        themePalette.classList.remove('show');
      });
    });
    
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.popup-theme-picker-btn') && !e.target.closest('.popup-theme-palette')) {
        themePalette.classList.remove('show');
      }
    });
  }

  // Initialize theme
  loadTheme();
  initThemePicker();

  // Check if first time opening popup and show login dialog
  checkFirstTimeUser();

  // Mock data for development when chrome.storage is not available
  const mockNotesData = {
    'https://developer.chrome.com/docs/extensions': [
      {
        content:
          'This is a mock note about Chrome extensions. Great for UI development!',
        top: '150px',
        left: '200px',
      },
    ],
    'https://www.google.com/search?q=mock+data': [
      {
        content:
          'A sticky note for Google! This is a sample note to show how content is displayed.',
        top: '100px',
        left: '50px',
      },
      {
        content:
          'Another note on Google. You can have multiple notes per page. <b>HTML content</b> like bold text is also supported.',
        top: '300px',
        left: '250px',
      },
    ],
    'https://partnerflow.co.za/': [
      {
        content:
          'This is a note on partnerflow.co.za. The popup groups notes by the main domain.',
        top: '220px',
        left: '400px',
      },
    ],
  };

  /**
   * Check if this is the first time user opens popup and show login dialog
   */
  function checkFirstTimeUser() {
    chrome.storage.local.get(['firstTimePopupShown', 'userToken'], (result) => {
      // Show dialog if: first time AND not logged in
      if (!result.firstTimePopupShown && !result.userToken) {
        showLoginDialog();
      }
    });
  }

  /**
   * Show the first-time login dialog
   */
  function showLoginDialog() {
    const overlay = document.getElementById('first-time-login-overlay');
    if (!overlay) return;

    overlay.classList.add('show');

    // Login Now button
    const loginNowBtn = document.getElementById('login-now-btn');
    if (loginNowBtn) {
      loginNowBtn.addEventListener('click', () => {
        // Mark as shown
        chrome.storage.local.set({ firstTimePopupShown: true });
        // Hide dialog
        overlay.classList.remove('show');
        // Open cloud storage page for login
        chrome.tabs.create({ url: chrome.runtime.getURL('pages/storage.html') });
      });
    }

    // Maybe Later button
    const loginLaterBtn = document.getElementById('login-later-btn');
    if (loginLaterBtn) {
      loginLaterBtn.addEventListener('click', () => {
        // Mark as shown so it doesn't appear again
        chrome.storage.local.set({ firstTimePopupShown: true });
        // Hide dialog
        overlay.classList.remove('show');
      });
    }
  }

  /**
   * Extracts the main domain from a given URL.
   * @param {string} url - The URL to process.
   * @returns {string|null} - The main domain (e.g., https://example.com) or null for invalid URLs.
   */
  function getMainDomain(url) {
    try {
      if (!url.startsWith('https://') && !url.startsWith('http://')) {
        // Assume https:// for URLs without a protocol
        url = `https://${url}`;
      }
      const urlObj = new URL(url);
      return urlObj.hostname;
    } catch (error) {
      console.warn('Invalid URL encountered:', url, error);
      return null; // Return null for invalid URLs
    }
  }

  /**
   * Shows a custom confirmation modal over a note item in the popup.
   * @param {HTMLElement} noteItem - The note item element to cover.
   * @param {function} onConfirm - The callback function to execute on confirmation.
   */
  function showPopupDeleteConfirmation(noteItem, onConfirm) {
    // Prevent multiple modals on the same item
    if (noteItem.querySelector('.popup-delete-overlay')) {
      return;
    }

    const overlay = document.createElement('div');
    overlay.className = 'popup-delete-overlay';

    const modal = document.createElement('div');
    modal.className = 'popup-delete-modal';
    modal.innerHTML = `
            <p>Delete this note?</p>
            <div class="popup-modal-buttons">
                <button class="confirm-delete">Delete</button>
                <button class="cancel-delete">Cancel</button>
            </div>
        `;

    overlay.appendChild(modal);
    noteItem.appendChild(overlay);

    modal.querySelector('.confirm-delete').addEventListener('click', (e) => {
      e.stopPropagation(); // Prevent event bubbling
      onConfirm();
      overlay.remove();
    });

    modal.querySelector('.cancel-delete').addEventListener('click', (e) => {
      e.stopPropagation();
      overlay.remove();
    });
  }

  /**
   * Renders notes in the popup, grouped by their main domain.
   * @param {object} notesData - The notes data from storage or mock data.
   * @param {string[]} [collapsedDomains=[]] - An array of domains that should be collapsed.
   * @param {boolean} [isSearchResult=false] - Flag to indicate if the data is from a search.
   */
  function renderNotes(
    notesData,
    collapsedDomains = [],
    isSearchResult = false
  ) {
    notesContainer.innerHTML = '';

    // Filter out any URLs that have empty note arrays to be safe
    const nonEmptyNotesData = Object.fromEntries(
      Object.entries(notesData).filter(
        ([, notes]) => Array.isArray(notes) && notes.length > 0
      )
    );

    if (Object.keys(nonEmptyNotesData).length === 0) {
      const noNotesMessage = document.createElement('div');
      noNotesMessage.className = 'no-notes-message';
      if (isSearchResult) {
        noNotesMessage.textContent = 'No notes found matching your search. 🕵️‍♂️';
      } else {
        noNotesMessage.textContent =
          'Oops! Your sticky note board is squeaky clean 🧼. Start scribbling to add some magic!';
      }
      notesContainer.appendChild(noNotesMessage);
      return;
    }

    const groupedNotes = {};
    for (const [url, notes] of Object.entries(nonEmptyNotesData)) {
      const mainDomain = getMainDomain(url);
      if (!mainDomain) continue;
      if (!groupedNotes[mainDomain]) groupedNotes[mainDomain] = [];
      groupedNotes[mainDomain].push({
        url,
        notes,
      });
    }

    for (const [domain, entries] of Object.entries(groupedNotes)) {
      const totalNotes = entries.reduce(
        (sum, entry) => sum + entry.notes.length,
        0
      );
      if (totalNotes === 0) continue;

      const domainContainer = document.createElement('div');
      domainContainer.className = 'domain-container';

      if (collapsedDomains.includes(domain)) {
        domainContainer.classList.add('collapsed');
      }

      const domainHeader = document.createElement('div');
      domainHeader.className = 'domain-header';

      const domainTitle = document.createElement('h3');
      domainTitle.className = 'ap-sn-site-title';

      const favicon = document.createElement('img');
      favicon.src = `https://www.google.com/s2/favicons?domain=${domain}`;
      favicon.className = 'favicon';
      domainTitle.appendChild(favicon);

      const domainText = document.createTextNode(domain);
      domainTitle.appendChild(domainText);

      const chevron = document.createElement('i');
      chevron.className = 'fi fi-rr-angle-small-down chevron-icon';

      domainHeader.appendChild(domainTitle);
      domainHeader.appendChild(chevron);

      const notesList = document.createElement('div');
      notesList.className = 'notes-list';

      // Create a wrapper for the notes to enable smooth collapse/expand animation
      const notesWrapper = document.createElement('div');
      notesWrapper.className = 'notes-wrapper';

      domainHeader.addEventListener('click', () => {
        domainContainer.classList.toggle('collapsed');
        updateCollapsedState(
          domain,
          domainContainer.classList.contains('collapsed')
        );
      });

      domainContainer.appendChild(domainHeader);
      domainContainer.appendChild(notesList);
      notesList.appendChild(notesWrapper); // The wrapper is the single child of the grid container

      entries.forEach(({ url, notes }) => {
        notes.forEach((note) => {
          const noteItem = document.createElement('div');
          noteItem.className = 'note-item';
          noteItem.style.borderLeft = `4px solid ${note.color || '#ffd165'}`;

          const noteTitle = document.createElement('div');
          noteTitle.className = 'note-item-title';
          noteTitle.textContent = note.title || 'Note';
          noteItem.appendChild(noteTitle);

          const noteContent = document.createElement('span');
          noteContent.innerHTML = note.content;
          noteItem.appendChild(noteContent);

          const noteOptions = document.createElement('div');
          noteOptions.className = 'note-options';

          const editButton = document.createElement('button');
          editButton.className = 'edit-note-button note-op-btn';
          editButton.innerHTML = '<i class="fi fi-rr-pencil"></i>';
          editButton.title = 'Edit Note';

          const saveButton = document.createElement('button');
          saveButton.className = 'save-note-button note-op-btn';
          saveButton.innerHTML = '<i class="fi fi-rr-check"></i>';
          saveButton.title = 'Save Note';
          saveButton.style.display = 'none';

          const discardButton = document.createElement('button');
          discardButton.className = 'discard-note-button note-op-btn';
          discardButton.innerHTML = '<i class="fi fi-rr-cross-small"></i>';
          discardButton.title = 'Discard Changes';
          discardButton.style.display = 'none';

          const copyButton = document.createElement('button');
          copyButton.className = 'copy-note-button note-op-btn';
          copyButton.innerHTML = '<i class="fi fi-rr-copy"></i>';
          copyButton.title = 'Copy Note';
          copyButton.addEventListener('click', () => {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = note.content;
            const textToCopy = tempDiv.textContent || tempDiv.innerText || '';

            navigator.clipboard
              .writeText(textToCopy)
              .then(() => {
                copyButton.innerHTML = '<i class="fi fi-rr-check"></i>';
                copyButton.title = 'Copied!';
                copyButton.classList.add('copied');
                setTimeout(() => {
                  copyButton.innerHTML = '<i class="fi fi-rr-copy"></i>';
                  copyButton.title = 'Copy Note';
                  copyButton.classList.remove('copied');
                }, 2000);
              })
              .catch((err) => {
                console.error('Failed to copy text: ', err);
                copyButton.title = 'Failed to copy';
                setTimeout(() => {
                  copyButton.title = 'Copy Note';
                }, 2000);
              });
          });

          const visitNoteButton = document.createElement('button');
          visitNoteButton.className = 'visit-note-button note-op-btn';
          visitNoteButton.innerHTML =
            '<i class="fi fi-rr-arrow-up-right-from-square"></i>';
          visitNoteButton.title = 'Go to Note';
          visitNoteButton.addEventListener('click', () => {
            chrome.tabs.create({
              url,
            });
          });

          if (
            typeof chrome === 'undefined' ||
            typeof chrome.tabs === 'undefined'
          ) {
            visitNoteButton.disabled = true;
            visitNoteButton.title =
              'Navigation is disabled in development mode.';
          }

          const deleteButton = document.createElement('button');
          deleteButton.className = 'p-delete-note-btn note-op-btn';
          deleteButton.innerHTML = '<i class="fi fi-rr-trash"></i>';
          deleteButton.title = 'Delete Note';
          deleteButton.addEventListener('click', () => {
            showPopupDeleteConfirmation(noteItem, () => {
              deleteNote(url, note);
            });
          });

          if (
            typeof chrome === 'undefined' ||
            typeof chrome.storage === 'undefined'
          ) {
            deleteButton.disabled = true;
            deleteButton.title = 'Deletion is disabled in development mode.';
          }

          let originalContent = note.content;

          editButton.addEventListener('click', () => {
            originalContent = noteContent.innerHTML;
            noteContent.contentEditable = true;
            noteContent.focus();
            noteItem.classList.add('editing');
            noteOptions.classList.add('editing');
            editButton.style.display = 'none';
            saveButton.style.display = 'flex';
            discardButton.style.display = 'flex';
            copyButton.style.display = 'none';
            visitNoteButton.style.display = 'none';
            deleteButton.style.display = 'none';
          });

          saveButton.addEventListener('click', () => {
            noteContent.contentEditable = false;
            noteItem.classList.remove('editing');
            noteOptions.classList.remove('editing');
            editButton.style.display = 'flex';
            saveButton.style.display = 'none';
            discardButton.style.display = 'none';
            copyButton.style.display = 'flex';
            visitNoteButton.style.display = 'flex';
            deleteButton.style.display = 'flex';

            const newContent = noteContent.innerHTML;
            updateNoteContent(url, note, newContent);
            note.content = newContent; // Update closure variable
          });

          discardButton.addEventListener('click', () => {
            noteContent.innerHTML = originalContent;
            noteContent.contentEditable = false;
            noteItem.classList.remove('editing');
            noteOptions.classList.remove('editing');
            editButton.style.display = 'flex';
            saveButton.style.display = 'none';
            discardButton.style.display = 'none';
            copyButton.style.display = 'flex';
            visitNoteButton.style.display = 'flex';
            deleteButton.style.display = 'flex';
          });

          noteOptions.appendChild(editButton);
          noteOptions.appendChild(saveButton);
          noteOptions.appendChild(discardButton);
          noteOptions.appendChild(copyButton);
          noteOptions.appendChild(visitNoteButton);
          noteOptions.appendChild(deleteButton);

          noteItem.appendChild(noteOptions);
          notesWrapper.appendChild(noteItem); // Append notes to the wrapper
        });
      });

      notesContainer.appendChild(domainContainer);
    }

    if (notesContainer.innerHTML === '') {
      const noNotesMessage = document.createElement('div');
      noNotesMessage.className = 'no-notes-message';
      noNotesMessage.textContent =
        'Oops! Your sticky note board is squeaky clean 🧼. Start scribbling to add some magic!';
      notesContainer.appendChild(noNotesMessage);
    }
  }

  /**
   * Updates the stored list of collapsed domains.
   * @param {string} domain - The domain to add or remove.
   * @param {boolean} isCollapsed - Whether the domain is now collapsed.
   */
  function updateCollapsedState(domain, isCollapsed) {
    if (
      typeof chrome === 'undefined' ||
      !chrome.storage ||
      !chrome.storage.sync
    ) {
      console.warn('Storage API not available. Cannot save collapsed state.');
      return;
    }

    chrome.storage.sync.get({ collapsed_domains: [] }, (data) => {
      if (chrome.runtime.lastError) {
        console.error(
          'Error getting collapsed state:',
          chrome.runtime.lastError
        );
        return;
      }

      const collapsedDomains = data.collapsed_domains;
      const domainIndex = collapsedDomains.indexOf(domain);

      if (isCollapsed && domainIndex === -1) {
        // Add to list if it's collapsed and not already there
        collapsedDomains.push(domain);
      } else if (!isCollapsed && domainIndex > -1) {
        // Remove from list if it's expanded and was in the list
        collapsedDomains.splice(domainIndex, 1);
      }

      chrome.storage.sync.set({ collapsed_domains: collapsedDomains }, () => {
        if (chrome.runtime.lastError) {
          console.error(
            'Error saving collapsed state:',
            chrome.runtime.lastError
          );
        }
      });
    });
  }

  /**
   * Loads notes from storage, or uses mock data if storage is unavailable.
   */
  function loadNotes() {
    // Check if we are in a real extension environment
    if (
      typeof chrome !== 'undefined' &&
      chrome.storage &&
      chrome.storage.sync
    ) {
      chrome.storage.sync.get(null, (data) => {
        if (chrome.runtime.lastError) {
          console.error('Error retrieving data:', chrome.runtime.lastError);
          return;
        }
        collapsedDomainsState = data.collapsed_domains || [];
        const notesData = { ...data };
        delete notesData.collapsed_domains; // Separate notes from state

        allNotesData = notesData;
        renderNotes(allNotesData, collapsedDomainsState);
      });
    } else {
      // Fallback to mock data for local development/testing
      console.warn(
        'chrome.storage.sync API not available. Loading mock data for development.'
      );
      allNotesData = mockNotesData;
      renderNotes(mockNotesData, []);
    }
  }

  /**
   * Filters notes based on a search term and re-renders the list.
   * @param {string} searchTerm - The term to filter by.
   */
  function filterAndRenderNotes(searchTerm) {
    if (!searchTerm) {
      renderNotes(allNotesData, collapsedDomainsState);
      return;
    }

    const filteredData = {};
    const term = searchTerm.toLowerCase();

    for (const [url, notes] of Object.entries(allNotesData)) {
      const domain = getMainDomain(url) || url;

      // Check if the domain itself matches the search term
      const domainMatches = domain.toLowerCase().includes(term);

      // Filter notes within this URL that match the content
      const matchingNotes = notes.filter((note) => {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = note.content;
        const noteText = tempDiv.textContent || tempDiv.innerText || '';
        const noteTitle = note.title || '';
        return (
          noteText.toLowerCase().includes(term) ||
          noteTitle.toLowerCase().includes(term)
        );
      });

      // If the domain matches or there are matching notes, add them
      if (domainMatches || matchingNotes.length > 0) {
        // If domain matches, add all notes; otherwise, add only matching notes
        filteredData[url] = domainMatches ? notes : matchingNotes;
      }
    }

    // When searching, expand all groups to show results.
    renderNotes(filteredData, [], true);
  }

  // Add event listener for the search input
  searchInput.addEventListener('input', () => {
    filterAndRenderNotes(searchInput.value);
  });

  /**
   * Updates the content of a specific note.
   * @param {string} url - The URL associated with the note.
   * @param {object} originalNote - The original note object to identify it.
   * @param {string} newContent - The new HTML content for the note.
   */
  function updateNoteContent(url, originalNote, newContent) {
    if (
      typeof chrome === 'undefined' ||
      !chrome.storage ||
      !chrome.storage.sync
    ) {
      console.warn('Storage API not available. Cannot update note.');
      return;
    }

    chrome.storage.sync.get(url, (data) => {
      if (chrome.runtime.lastError) {
        console.error(
          'Error retrieving notes for update:',
          chrome.runtime.lastError
        );
        return;
      }

      const notes = data[url] || [];
      // Find note by position and title. Content can be stale if edited in another tab/page.
      const noteIndex = notes.findIndex(
        (note) =>
          note.top === originalNote.top &&
          note.left === originalNote.left &&
          note.title === originalNote.title
      );

      if (noteIndex > -1) {
        notes[noteIndex].content = newContent;

        chrome.storage.sync.set({ [url]: notes }, () => {
          if (chrome.runtime.lastError) {
            console.error(
              'Error saving updated note:',
              chrome.runtime.lastError
            );
          }
        });
      } else {
        console.warn(
          'Could not find the note to update. It might have been edited in another tab. Reloading notes.',
          originalNote
        );
        loadNotes(); // Fallback to reload all notes if something is out of sync
      }
    });
  }

  /**
   * Deletes a specific note for a given URL and refreshes the display.
   * @param {string} url - The URL associated with the note.
   * @param {object} noteToDelete - The note to delete (identified by content and position).
   */
  function deleteNote(url, noteToDelete) {
    chrome.storage.sync.get(url, (data) => {
      if (chrome.runtime.lastError) {
        console.error(
          'Error retrieving notes for deletion:',
          chrome.runtime.lastError
        );
        return;
      }

      const notes = data[url] || [];
      // Find the index of the note to delete using stable properties to avoid ambiguity
      const noteIndexToDelete = notes.findIndex(
        (note) =>
          note.top === noteToDelete.top &&
          note.left === noteToDelete.left &&
          note.title === noteToDelete.title
      );

      if (noteIndexToDelete === -1) {
        console.warn(
          'Could not find the note to delete. It might have been modified. Reloading notes.',
          noteToDelete
        );
        loadNotes();
        return; // Stop execution to prevent deleting the wrong note
      }

      // Create a new array with the note removed.
      const updatedNotes = notes.filter(
        (_, index) => index !== noteIndexToDelete
      );

      if (updatedNotes.length === 0) {
        // Remove the URL if no notes are left
        chrome.storage.sync.remove(url, () => {
          if (chrome.runtime.lastError) {
            console.error(
              'Error removing URL from storage:',
              chrome.runtime.lastError
            );
          } else {
            loadNotes(); // Refresh the display
          }
        });
      } else {
        // Update the remaining notes
        chrome.storage.sync.set(
          {
            [url]: updatedNotes,
          },
          () => {
            if (chrome.runtime.lastError) {
              console.error(
                'Error saving updated notes:',
                chrome.runtime.lastError
              );
            } else {
              loadNotes(); // Refresh the display
            }
          }
        );
      }
    });
  }

  // Load notes when the popup is opened
  loadNotes();
});
